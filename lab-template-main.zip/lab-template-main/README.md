# lab2672
This is a repository containing sample Terraform files used in TechXchange 2025 lab session 2672
